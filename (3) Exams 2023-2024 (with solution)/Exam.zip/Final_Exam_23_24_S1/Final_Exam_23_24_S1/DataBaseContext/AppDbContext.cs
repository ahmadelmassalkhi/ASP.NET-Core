﻿using Microsoft.EntityFrameworkCore;
using Final_Exam_23_24_S1.Models;
namespace Final_Exam_23_24_S1.DataBaseContext
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<ClientDataModel> ClientModel { get; set; }
    }
}
