//////////////////////////////////////////////////////////////
//////////////////  HASAN MOHAMMAD JAFFAL - 105666  /////////////////////

using Final_Exam_23_24_S1.DataBaseContext;
using Final_Exam_23_24_S1.Models;
using Final_Exam_23_24_S1.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;

var builder = WebApplication.CreateBuilder(args);
// Add services to the container.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddRazorPages();

//Data Base Registration
var conString = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddDbContext<AppDbContext> (
    options => options.UseSqlServer(conString)
);

builder.Services.AddScoped<ICustomerService, CustomerService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

//  --------- Minimal APIs - Endpoints  ----------- //
// Access Swagger at http://localhost:5050/swagger/index.html

app.MapGet("/SayHi", () => { return "HI"; });
app.MapPost("/AddCustomer", (ICustomerService service, ClientCreateModel model) => service.AddCustomer(model));
app.MapPut("/CorrectBalances", (ICustomerService service, int id,  int usd,  int lbp) => service.CorrectBalances(id, usd, lbp));
app.MapGet("GetCustomer", (ICustomerService service, int id) => service.GetClientById(id));




/////////////////////////////////////////////////////
app.MapRazorPages();
app.Run();
