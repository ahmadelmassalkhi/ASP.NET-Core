using Final_Exam_23_24_S1.Models;
using Final_Exam_23_24_S1.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Final_Exam_23_24_S1.Pages
{
    public class DepositModel : PageModel
    {
        private readonly ICustomerService _customerService;
        public DepositModel (ICustomerService customerService)
        {
            _customerService = customerService;
        }
        public ClientBindingModel ClientBindingModel { get; set; }
        public IActionResult OnPost()
        {
            var clientId = _customerService.Deposit(ClientBindingModel);
            if (clientId == null)
            {
                return Page();
            }
            return RedirectToPage($"Success/{clientId}");
        }
    }
}
