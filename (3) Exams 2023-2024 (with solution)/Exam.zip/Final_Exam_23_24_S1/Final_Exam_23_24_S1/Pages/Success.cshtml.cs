using Final_Exam_23_24_S1.Models;
using Final_Exam_23_24_S1.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Final_Exam_23_24_S1.Pages
{
    public class SuccessModel : PageModel
    {
        private readonly ICustomerService _customerService;
        public SuccessModel(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        public ClientDataModel Client { get; set; }
        public async Task<IActionResult> OnGet(int id)
        {
            Client = await _customerService.GetClientById(id);
            return RedirectToPage(new { id });
        }
    }
}
