using Final_Exam_23_24_S1.Models;
using Final_Exam_23_24_S1.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Final_Exam_23_24_S1.Pages
{
    public class WithdrawModel : PageModel
    {
        private readonly ICustomerService _customerService;
        public WithdrawModel(ICustomerService customerService)
        {
            _customerService = customerService;
        }
        public ClientBindingModel ClientBindingModel { get; set; }
        public IActionResult OnPost()
        {
            var clientId = _customerService.Withdraw(ClientBindingModel);
            if (clientId == null)
            {
                return Page();
            }
            return RedirectToPage($"Success/{clientId}");
        }
    }
}
