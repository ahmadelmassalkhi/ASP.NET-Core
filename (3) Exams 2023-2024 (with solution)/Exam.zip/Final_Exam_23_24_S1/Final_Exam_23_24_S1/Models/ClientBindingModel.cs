﻿using System.ComponentModel.DataAnnotations;

namespace Final_Exam_23_24_S1.Models
{
    public class ClientBindingModel
    {
        public int Id { get; set; }
        [Range(0, 1000)]
        public int USD_Value { get; set; }
        [Range(0, 10000000)]
        public int LBP_Value { get; set; }
    }
}
