﻿using System.ComponentModel.DataAnnotations;

namespace Final_Exam_23_24_S1.Models
{
    public class ClientDataModel
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public int USD_Balance { get; set; }
        public int LBP_Balance { get; set; }
    }
}
