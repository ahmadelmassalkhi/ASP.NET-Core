﻿namespace Final_Exam_23_24_S1.Models
{
    public class ClientCreateModel
    {
        public string Name { get; set; }
        public int USD_Balance { get; set; }
        public int LBP_Balance { get; set; }
    }
}
