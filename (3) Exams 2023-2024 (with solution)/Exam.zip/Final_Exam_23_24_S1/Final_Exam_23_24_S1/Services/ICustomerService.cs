﻿using Final_Exam_23_24_S1.Models;
using Microsoft.AspNetCore.Mvc.ApplicationModels;

namespace Final_Exam_23_24_S1.Services
{
    public interface ICustomerService
    {
        public Task<int> Deposit(ClientBindingModel model);
        public Task<int> Withdraw(ClientBindingModel model);
        public Task<ClientDataModel> GetClientById(int id);
        public Task<int> AddCustomer(ClientCreateModel model);
        public Task<ClientDataModel> CorrectBalances(int Id, int USD, int LBP);
    }
}
