﻿using Final_Exam_23_24_S1.DataBaseContext;
using Final_Exam_23_24_S1.Models;
using Microsoft.EntityFrameworkCore;

namespace Final_Exam_23_24_S1.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly AppDbContext _db;
        public CustomerService(AppDbContext db)
        {
            _db = db;
        }

        public async Task<int> AddCustomer(ClientCreateModel model)
        {
            ClientDataModel newClient = new ClientDataModel();
            newClient.Name = model.Name;
            newClient.LBP_Balance = model.LBP_Balance;
            newClient.USD_Balance = model.USD_Balance;
            await _db.ClientModel.AddAsync(newClient);
            await _db.SaveChangesAsync();
            return newClient.Id;
        }

        public async Task<ClientDataModel> CorrectBalances(int Id, int USD, int LBP)
        {
            ClientDataModel newClient = await _db.ClientModel.FirstOrDefaultAsync(x => x.Id == Id);
            if (newClient == null)
            {
                Results.NotFound();
            }
            newClient.LBP_Balance = LBP;
            newClient.USD_Balance = USD;
            _db.Update(newClient);
            await _db.SaveChangesAsync();
            return newClient;
        }

        public async Task<int> Deposit(ClientBindingModel model)
        {
            ClientDataModel newEntity = new ClientDataModel();

            newEntity = await _db.ClientModel.FirstOrDefaultAsync(x => x.Id == model.Id);
            newEntity.LBP_Balance += model.LBP_Value;
            newEntity.USD_Balance += model.USD_Value;
            _db.ClientModel.Update(newEntity);
            await _db.SaveChangesAsync();
            return newEntity.Id;
        }

        public async Task<ClientDataModel> GetClientById(int id)
        {
            var client = await _db.ClientModel.FirstOrDefaultAsync(x => x.Id == id);
            if (client == null)
            {
                Results.NotFound("Id does not exist");
            }
            return client;
        }

        public async Task<int> Withdraw(ClientBindingModel model)
        {
            ClientDataModel newEntity = new ClientDataModel();

            newEntity = await _db.ClientModel.FirstOrDefaultAsync(x => x.Id == model.Id);
            newEntity.LBP_Balance -= model.LBP_Value;
            newEntity.USD_Balance -= model.USD_Value;
            _db.ClientModel.Update(newEntity);
            await _db.SaveChangesAsync();
            return newEntity.Id;
        }
    }
}
