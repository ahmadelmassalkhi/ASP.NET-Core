//////////////////////////////////////////////////////////////
//////////////////  YOUR FULL NAME - ID  /////////////////////

using Final_Exam_23_24_S1.DataBaseContext;
using Final_Exam_23_24_S1.Models;
using Final_Exam_23_24_S1.Services;
using Microsoft.EntityFrameworkCore;
using System;

var builder = WebApplication.CreateBuilder(args);
// Add services to the container.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddRazorPages();

//Data Base Registration
var conString = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddDbContext<AppDbContext>(
    options => options.UseSqlServer(conString));

builder.Services.AddScoped<CustomerService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

//  --------- Minimal APIs - Endpoints  ----------- //
// Access Swagger at http://localhost:5050/swagger/index.html
app.MapGet("/SayHi", () => { return "HI"; });

app.MapPost("/AddCustomer", async (AppDbContext context, CustomerCreateDto customerDto) =>
{
    // Create a new customer instance without setting the Id
    var newCustomer = new CustomerDataModel
    {
        Name = customerDto.Name,
        USD_Balance = customerDto.USD_Balance,
        LBP_Balance = customerDto.LBP_Balance
    };

    context.CustomerModel.Add(newCustomer);
    await context.SaveChangesAsync();
    // Return the auto-generated Id
    return Results.Ok(newCustomer.Id);
});


app.MapPut("/CorrectBalances/{id:int}/{usd:int}/{lbp:int}", async (AppDbContext context, int id, int usd, int lbp) =>
{
    var customer = await context.CustomerModel.FindAsync(id);
    if (customer == null)
    {
        return Results.Problem(
            title: "Customer Not Found",
            statusCode: 404,
            detail: $"Customer with ID {id} not found."
        );
    }

    customer.USD_Balance = usd;
    customer.LBP_Balance = lbp;
    await context.SaveChangesAsync();

    return Results.Ok(customer);
});

app.MapGet("/GetCustomer/{id:int}", async (AppDbContext context, int id) =>
{
    var customer = await context.CustomerModel.FindAsync(id);
    if (customer == null)
    {
        return Results.Problem(
            title: "Customer Not Found",
            statusCode: 404,
            detail: $"Customer with ID {id} not found."
        );
    }

    return Results.Ok(customer);
});
/////////////////////////////////////////////////////

app.MapRazorPages();

app.Run();
