using Final_Exam_23_24_S1.DataBaseContext;
using Final_Exam_23_24_S1.Models;
using Final_Exam_23_24_S1.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Final_Exam_23_24_S1.Pages
{
    public class DepositModel : PageModel
    {
        [BindProperty]
        public CustomerBindingModel CustomerBindingModel { get; set; }
        public CustomerViewModel CustomerViewModel { get; set; }

        private readonly CustomerService _customerService;
        private readonly AppDbContext _context;

        public DepositModel(CustomerService customerService, AppDbContext context)
        {
            _customerService = customerService;
            _context = context;
        }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                // Return the page with validation errors
                return Page();
            }

            var customer = await _context.CustomerModel.FindAsync(CustomerBindingModel.Id);
            if (customer == null)
            {
                ModelState.AddModelError(string.Empty, "Customer ID does not exist.");
                return Page();
            }

            await _customerService.DepositBalancesAsync(
                CustomerBindingModel.Id,
                CustomerBindingModel.USD,
                CustomerBindingModel.LBP
            );

            // Redirect to Balance page after successful operation
            return RedirectToPage("/Success", new { id = CustomerBindingModel.Id });
        }
    }
}
