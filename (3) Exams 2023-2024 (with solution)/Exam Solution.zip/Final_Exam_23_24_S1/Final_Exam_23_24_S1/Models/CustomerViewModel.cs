﻿using System.ComponentModel.DataAnnotations;

namespace Final_Exam_23_24_S1.Models
{
    public class CustomerViewModel
    {
        [Required]
        [Range(0, int.MaxValue)]
        public int Id { get; set; }
        [Required]
        [Range(0, 1000)]
        public int USD { get; set; } = 0;
        [Required]
        [Range(0, 1000000)]
        public int LBP { get; set; } = 0;
    }
}
