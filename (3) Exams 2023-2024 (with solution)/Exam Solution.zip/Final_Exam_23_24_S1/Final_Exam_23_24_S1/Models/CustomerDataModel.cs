﻿using System.ComponentModel.DataAnnotations;

namespace Final_Exam_23_24_S1.Models
{
    public class CustomerDataModel
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; } = "NoName";
        public int USD_Balance { get; set; } = 0;
        public int LBP_Balance { get; set; } = 0;
    }
}
