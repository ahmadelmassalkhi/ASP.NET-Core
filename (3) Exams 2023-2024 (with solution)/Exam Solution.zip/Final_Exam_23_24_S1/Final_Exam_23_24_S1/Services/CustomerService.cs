﻿using Final_Exam_23_24_S1.DataBaseContext;

namespace Final_Exam_23_24_S1.Services
{
    public class CustomerService
    {
        private readonly AppDbContext _context;

        public CustomerService(AppDbContext context)
        {
            _context = context;
        }

        public async Task DepositBalancesAsync(int customerId, int usdAmount, int lbpAmount)
        {
            var customer = await _context.CustomerModel.FindAsync(customerId);
            customer.USD_Balance += usdAmount;
            customer.LBP_Balance += lbpAmount;
            await _context.SaveChangesAsync();
        }

        public async Task WithdrawBalancesAsync(int customerId, int usdAmount, int lbpAmount)
        {
            var customer = await _context.CustomerModel.FindAsync(customerId);
            customer.USD_Balance -= usdAmount;
            customer.LBP_Balance -= lbpAmount;
            await _context.SaveChangesAsync();
        }
    }
}
