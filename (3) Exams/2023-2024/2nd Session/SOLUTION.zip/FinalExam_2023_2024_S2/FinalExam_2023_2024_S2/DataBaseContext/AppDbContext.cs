﻿using Microsoft.EntityFrameworkCore;
using Final_Exam_23_24_S1.Models;
namespace Final_Exam_23_24_S1.DataBaseContext
{
    // ---------  DO NOT MODIFY THIS FILE  ------------- 
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<Book> Books { get; set; }
    }
}
// ---------  DO NOT MODIFY THIS FILE  ------------- 