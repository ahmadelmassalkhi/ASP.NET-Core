﻿using System.ComponentModel.DataAnnotations;

namespace Final_Exam_23_24_S1.Models
{
    
    // ---------  DO NOT MODIFY THIS FILE  ------------- 
    public class Book
    {
        [Key]
        public int BookId { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
    }
}
// ---------  DO NOT MODIFY THIS FILE  ------------- 