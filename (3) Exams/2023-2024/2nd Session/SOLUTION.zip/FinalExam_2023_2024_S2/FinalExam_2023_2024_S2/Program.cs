//////////////////////////////////////////////////////////////
//////////////////  LITERALLY PATRICK BATEMAN - 666666  /////////////////////
using Final_Exam_23_24_S1.Models;
using Final_Exam_23_24_S1.DataBaseContext;
using Microsoft.EntityFrameworkCore;
using System;

var builder = WebApplication.CreateBuilder(args);
// Add services to the container.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddRazorPages();

//Data Base Registration
builder.Services.AddDbContext<AppDbContext>(
    options => options.UseInMemoryDatabase("ilikedominantfemales"));

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

//  --------- Minimal APIs - Endpoints  ----------- //
// Access Swagger at http://localhost:5050/swagger/index.html

app.MapGet("/SayHi", () => { return "HI"; });


/*****************************
  RESPECT THE NAMES OF THE ENDPOINTS AS SHOWN IN THE VIDEO, 
  OTHERWISE YOU  WILL LOSE ITS MARKS. 
 *****************************/




// Endpoint to add a new book using query string parameters
app.MapGet("/addbook", async (AppDbContext context, string title, string author) =>
{
    Book book = new()
    {
        Title = title,
        Author = author
    };
    await context.Books.AddAsync(book);
    await context.SaveChangesAsync();
    return Results.Ok(book);
});

// Endpoint to get a book by ID
app.MapGet("/books/{id}", async (AppDbContext context, int id) =>
{
    var book = await context.Books.FindAsync(id);
    if (book == null) return Results.Problem($"Book with ID {id} not found.");
    return Results.Ok(book);
});

// Endpoint to get all books
app.MapGet("/books", async (AppDbContext context) =>
{
    return Results.Ok(await context.Books.ToListAsync());
});

// Endpoint to update the author's name by book ID
app.MapPut("books/{id}/updateauthor", async (AppDbContext context, int id, string author) =>
{
    var book = await context.Books.FindAsync(id);
    if (book == null) return Results.Problem($"Book with ID {id} not found.");
    book.Author = author;
    await context.SaveChangesAsync();
    return Results.Ok($"Author for book with ID {id} has been updated to '{author}'.");
});

// Endpoint to delete a book by title passed as query string parameter
app.MapDelete("/deletebookbytitle", async (AppDbContext context, string title) =>
{
    var book = await context.Books.FirstOrDefaultAsync(b => b.Title == title);
    if(book == null) return Results.Problem($"Book with title '{title}' not found.");
    context.Books.Remove(book);
    await context.SaveChangesAsync();
    return Results.Ok($"Book with title '{title}' has been deleted.");
});

// Endpoint to compare two books by IDs and delete the one with greater ID if they are the same
app.MapDelete("/comparebooks/{id1}/{id2}", async (AppDbContext context, int id1, int id2) =>
{
    // get both books
    var book1 = await context.Books.FindAsync(id1);
    var book2 = await context.Books.FindAsync(id2);
    if(book1==null || book2==null) return Results.Problem($"One or both of the books were not found.");
    
    // check if both are the same or not
    if(book1.Title==book2.Title && book1.Author==book2.Author)
    {
        // delete the book with greater ID
        if(book1.BookId > book2.BookId) context.Books.Remove(book1);
        else context.Books.Remove(book2);

        // save changes
        await context.SaveChangesAsync();

        // return message
        return Results.Ok($"Book with ID {Math.Max(id1, id2)} has been deleted because it is a duplicate of book with ID {Math.Min(id1, id2)}");
    }

    // return message
    return Results.Ok("The books are not the same, so no action was taken.");
});

/////////////////////////////////////////////////////
app.MapRazorPages();
app.Run();
