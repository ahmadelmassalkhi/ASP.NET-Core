using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Final_Exam_23_24_S1.Models;
using Final_Exam_23_24_S1.DataBaseContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Threading.Tasks;
namespace FinalExam_2023_2024_S2.Pages
{
    public class ResultModel : PageModel
    {
        public AppDbContext _context {  get; set; }
        public ResultModel(AppDbContext context)
        {
            _context = context;
        }

        public IList<Book> Books { get; set; }

        public async Task<IActionResult> OnGet(string? search)
        {
            if(search==null || search.IsNullOrEmpty()) return NotFound();
            Books = await _context.Books
                .Where(b => b.Title.Contains(search) || b.Author.Contains(search))
                .ToListAsync();
            return Page();

            //// BETTER FOR CASE-INSENSITIVITY (BUT WHO CARES, ITS FOR AN EXAM)
            //Books = await _context.Books
            //    .Where(b => EF.Functions.Like(b.Title, $"%{search}%") || EF.Functions.Like(b.Author, $"%{search}%"))
            //    .ToListAsync();
            //return Page();
        }

    }
}
