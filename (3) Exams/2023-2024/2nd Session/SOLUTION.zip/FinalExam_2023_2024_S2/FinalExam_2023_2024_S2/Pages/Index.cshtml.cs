﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using Final_Exam_23_24_S1.DataBaseContext;
using Final_Exam_23_24_S1.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;


namespace FinalExam_2023_2024_S2.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly AppDbContext _context;

        public IndexModel(ILogger<IndexModel> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IList<Book> Books { get; set; }

        public async Task OnGetAsync()
        {
            Books = await _context.Books.ToListAsync<Book>();
        }

        [BindProperty]
        public string? searchTerm { get; set; }
        public async Task<IActionResult> OnPost()
        {
            if(searchTerm == null || searchTerm.IsNullOrEmpty())
            {
                Books = await _context.Books.ToListAsync<Book>();
                return Page();
            }
            return RedirectToPage("/Result", new { search = searchTerm });
        }
    }
}
